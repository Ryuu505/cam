<!DOCTYPE html>
<html>
<head>
    <title>Reamz</title>
    <style>
        /* Gaya umum */
        body {
          font-family: Arial, sans-serif;
        }

        .container {
          max-width: 960px;
          margin: 0 auto;
          padding: 20px;
        }

        /* Gaya tampilan header */
        .header {
          background-color: #3b5998;
          color: #fff;
          padding: 10px;
        }

        .header h1 {
          margin: 0;
          font-size: 24px;
        }

        /* Gaya tampilan konten */
        .content {
          background-color: #f0f2f5;
          padding: 20px;
        }

        /* Gaya tampilan postingan */
        .post {
          background-color: #fff;
          border: 1px solid #ccc;
          border-radius: 5px;
          padding: 10px;
          margin-bottom: 10px;
        }

        /* Responsif untuk layar kecil */
        @media only screen and (max-width: 600px) {
          .container {
            padding: 10px;
          }

          .header h1 {
            font-size: 20px;
          }

          .content {
            padding: 10px;
          }

          .post {
            padding: 5px;
            margin-bottom: 5px;
          }
        }
    </style>
    <script>
     
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Reamz</h1>
        </div>
        <div class="content">
            <form action="ramzi.php" method="post">
                <input type="text" name="url" placeholder="Masukkan URL">
                <button type="submit">Gas</button>
            </form>
        </div>
    </div>
</body>
</html>
