<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $imageData = $_POST['imageData'];

    $imageData = str_replace('data:image/png;base64,', '', $imageData);
    $imageData = str_replace(' ', '+', $imageData);
    $imageBinary = base64_decode($imageData);

    $outputDir = 'gambar/';

    if (!is_dir($outputDir)) {
        mkdir($outputDir, 0777, true);
    }

    $filename = date('YmdHis') . '.png';

    $outputFile = $outputDir . $filename;

    file_put_contents($outputFile, $imageBinary);

    echo 'Gambar berhasil disimpan di ' . $outputFile;
}
?>
